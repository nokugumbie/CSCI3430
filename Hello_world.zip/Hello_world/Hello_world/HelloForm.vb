﻿Imports System.Drawing
Imports System.Windows.Forms

Public Class HelloForm
    Inherits Form

    Public Sub New()
        Me.Text = "Hello World"
        Me.BackColor = Color.Lime
        Me.ClientSize = New Size(300, 150)
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.StartPosition = FormStartPosition.CenterScreen

        Dim lblHello As New Label()
        lblHello.Text = "Hello World"
        lblHello.Font = New Font("Georgia", 18, FontStyle.Bold)
        lblHello.TextAlign = ContentAlignment.MiddleCenter
        lblHello.AutoSize = False
        lblHello.Size = New Size(280, 40)
        lblHello.Location = New Point(10, 15)
        Me.Controls.Add(lblHello)

        Dim btnOk As New Button()
        btnOk.Text = "OK"
        btnOk.BackColor = Color.PeachPuff
        btnOk.Size = New Size(90, 30)
        btnOk.Location = New Point(105, 65)
        AddHandler btnOk.Click, AddressOf btnOk_Click
        Me.Controls.Add(btnOk)


        Dim lblName As New Label()
        lblName.Text = "CSCI3430 - Nokutenda Gumbie A00477490"
        lblName.Font = New Font("Georgia", 10, FontStyle.Italic)
        lblName.TextAlign = ContentAlignment.MiddleCenter
        lblName.AutoSize = False
        lblName.Size = New Size(280, 25)
        lblName.Location = New Point(10, 110)
        Me.Controls.Add(lblName)
    End Sub

    Private Sub btnOk_Click(sender As Object, e As EventArgs)
        End   ' the single "End" instruction the assignment asks for
    End Sub

    Private Sub InitializeComponent()
        Me.SuspendLayout()
        '
        'HelloForm
        '
        Me.BackColor = System.Drawing.Color.Lime
        Me.ClientSize = New System.Drawing.Size(274, 229)
        Me.Name = "HelloForm"
        Me.ResumeLayout(False)

    End Sub
End Class
