﻿Public Class Form1
    Private clock As New System.Diagnostics.Stopwatch()

    Private Sub ShowTime()
        Dim t As TimeSpan = clock.Elapsed
        Dim hours As Integer = CInt(Math.Floor(t.TotalHours))
        Label2.Text = String.Format("{0:00}:{1:00}:{2:00}.{3:00}", hours, t.Minutes, t.Seconds, t.Milliseconds \ 10)
    End Sub
    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim wasRunning As Boolean = clock.IsRunning
        clock.Reset()
        If wasRunning Then clock.Start()
        ShowTime()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim b As Button = DirectCast(sender, Button)
        If clock.IsRunning Then
            clock.Stop()
            Timer1.Stop()
            b.Text = "Start"
            ShowTime()
        Else
            clock.Start()
            Timer1.Start()
            b.Text = "Stop"
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ShowTime()
    End Sub
End Class
