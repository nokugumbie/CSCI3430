﻿Public Class Calculator

    Private Const CM_PER_INCH As Double = 2.54
    Private Const MAX_DIGITS As Integer = 12

    Private entry As String = ""

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.KeyPreview = True

        For Each c As Control In Me.Controls
            Dim b As Button = TryCast(c, Button)
            If b IsNot Nothing Then
                b.TabStop = False
                AddHandler b.Click, AddressOf AnyButton_Click
            End If
        Next

        UpdateDisplay()
    End Sub

    Private Sub AnyButton_Click(sender As Object, e As EventArgs)
        Dim t As String = DirectCast(sender, Button).Text
        If t = "CE" Then
            ClearEntry()
        ElseIf t = "Back" OrElse t = ChrW(&H232B).ToString() Then
            Backspace()
        ElseIf t.Length = 1 AndAlso "0123456789.".Contains(t) Then
            PressKey(t(0))
        End If
    End Sub

    Private Sub PressKey(c As Char)
        If c = "."c Then
            If entry.Contains(".") Then Return
            entry = If(entry = "", "0.", entry & ".")
        Else
            If entry = "0" Then
                entry = c.ToString()
            ElseIf entry.Replace(".", "").Length < MAX_DIGITS Then
                entry &= c
            End If
        End If
        UpdateDisplay()
    End Sub

    Private Sub Backspace()
        If entry.Length > 0 Then entry = entry.Substring(0, entry.Length - 1)
        UpdateDisplay()
    End Sub

    Private Sub ClearEntry()
        entry = ""
        UpdateDisplay()
    End Sub

    Private Sub Form1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress
        Dim c As Char = e.KeyChar
        If c >= "0"c AndAlso c <= "9"c Then
            PressKey(c)
            e.Handled = True
        ElseIf c = "."c Then
            PressKey("."c)
            e.Handled = True
        ElseIf c = ControlChars.Back Then
            Backspace()
            e.Handled = True
        End If
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Delete OrElse e.KeyCode = Keys.Escape Then
            ClearEntry()
            e.Handled = True
        End If
    End Sub

    Private Sub UpdateDisplay()
        Dim text As String = If(entry = "", "0", entry)

        Dim inches As Double
        Double.TryParse(text, Globalization.NumberStyles.Float,
                        Globalization.CultureInfo.InvariantCulture, inches)

        Label2.Text = FormatWithCommas(text)
        Label4.Text = (inches * CM_PER_INCH).ToString("#,##0.########",
                        Globalization.CultureInfo.InvariantCulture)
    End Sub

    Private Function FormatWithCommas(s As String) As String
        Dim dot As Integer = s.IndexOf("."c)
        Dim whole As String = If(dot >= 0, s.Substring(0, dot), s)
        Dim rest As String = If(dot >= 0, s.Substring(dot), "")
        Dim n As Decimal = Decimal.Parse(whole, Globalization.CultureInfo.InvariantCulture)
        Return n.ToString("N0", Globalization.CultureInfo.InvariantCulture) & rest
    End Function
End Class
