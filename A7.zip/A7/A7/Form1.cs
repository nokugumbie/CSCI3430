using System.Runtime.CompilerServices;
using System.Media;

namespace A7
{
    public partial class Form1 : Form
    {
        float ballX = 100, ballY = 100, vx = 5, vy = 4;
        int paddleWidth = 14, paddleX = 30;
        float leftY = 150, rightY = 150;
        int leftScore = 0, rightScore = 0;
        bool keyUp, keyDown;
        Random rng = new Random();

        public Form1()
        {
            InitializeComponent();
            KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.W || e.KeyCode == Keys.Q) keyUp = true;
                if (e.KeyCode == Keys.S || e.KeyCode == Keys.A) keyDown = true;
            };
            KeyUp += (s, e) =>
            {
                if (e.KeyCode == Keys.W || e.KeyCode == Keys.Q) keyUp = false;
                if (e.KeyCode == Keys.S || e.KeyCode == Keys.A) keyDown = false;
            };
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int h = ClientSize.Height;
            int paddleHeight = h / 4;
            int w = ClientSize.Width;

            if (keyUp) leftY -= 8;
            if (keyDown) leftY += 8;
            leftY = Math.Max(0, Math.Min(h - paddleHeight, leftY));

            rightY = ballY + 50 / 2 - paddleHeight / 2;
            rightY = Math.Max(0, Math.Min(h - paddleHeight, rightY));
            ballX += vx;
            ballY += vy;

            if (ballY < 0) { ballY = 0; vy = Math.Abs(vy); }
            if (ballY + 50 > h) { ballY = h - 50; vy = -Math.Abs(vy); }

            // left paddle
            if (vx < 0 && ballX <= paddleX + paddleWidth && ballX + 50 >= paddleX &&
                ballY + 50 >= leftY && ballY <= leftY + paddleHeight)
            {
                ballX = paddleX + paddleWidth;
                vx = -vx;
            }

            // right paddle
            int rightPaddleX = w - paddleX - paddleWidth;
            if (vx > 0 && ballX + 50 >= rightPaddleX && ballX <= rightPaddleX + paddleWidth &&
                ballY + 50 >= rightY && ballY <= rightY + paddleHeight)
            {
                ballX = rightPaddleX - 50;
                vx = -vx;
            }

            if (ballX + 50 < 0) { rightScore++; AfterPoint(); return; }
            if (ballX > w) { leftScore++; AfterPoint(); return; }

            Invalidate();
        }

        private void AfterPoint()
        {
            if (leftScore >= 5 || rightScore >= 5)
            {
                timer1.Stop();
                Refresh();
                SystemSounds.Exclamation.Play();
                string who = leftScore >= 5 ? "You win!" : "The computer wins!";
                var result = MessageBox.Show(who + " Try again?", "Game Over", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    leftScore = 0;
                    rightScore = 0;
                    ResetBall();
                    timer1.Start();
                }
                else
                {
                    Close();
                }
            }
            else
            {
                ResetBall();
            }
            Invalidate();
        }

        private void ResetBall()
        {
            ballX = ClientSize.Width / 2 - 50 / 2;
            ballY = ClientSize.Height / 2 - 50 / 2;
            vx = rng.Next(2) == 0 ? 5 : -5;
            vy = rng.Next(-4, 5);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            int w = ClientSize.Width, h = ClientSize.Height;
            int paddleHeight = h / 4;

            using (var pen = new Pen(Color.Purple, 3))
            {
                pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                g.DrawLine(pen, w / 2, 0, w / 2, h);
            }

            using (var font = new Font("Consolas", 36, FontStyle.Bold))
            {
                g.DrawString(leftScore.ToString("00"), font, Brushes.DarkMagenta, w / 4 - 30, 10);
                g.DrawString(rightScore.ToString("00"), font, Brushes.DarkSlateBlue, 3 * w / 4 - 30, 10);
            }

            g.FillRectangle(Brushes.DarkMagenta, paddleX, leftY, paddleWidth, paddleHeight);
            g.FillRectangle(Brushes.DarkSlateBlue, w - paddleX - paddleWidth, rightY, paddleWidth, paddleHeight);
            g.FillEllipse(Brushes.Purple, ballX, ballY, 50, 50);
        }
    }
}
